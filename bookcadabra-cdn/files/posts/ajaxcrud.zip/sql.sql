# --------------------------------------------------------
# Host:                         127.0.0.1
# Database:                     test
# Server version:               5.5.8
# Server OS:                    Win32
# HeidiSQL version:             5.0.0.3272
# Date/time:                    2011-06-24 02:06:01
# --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
# Dumping database structure for test
CREATE DATABASE IF NOT EXISTS `test` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `test`;


# Dumping structure for table test.departments
CREATE TABLE IF NOT EXISTS `departments` (
  `dept_id` int(10) NOT NULL AUTO_INCREMENT,
  `dept_name` varchar(25) NOT NULL,
  PRIMARY KEY (`dept_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

# Dumping data for table test.departments: 0 rows
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` (`dept_id`, `dept_name`) VALUES (1, 'Finance'), (2, 'Marketing'), (3, 'Human Resources');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;


# Dumping structure for table test.employees
CREATE TABLE IF NOT EXISTS `employees` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `fname` varchar(25) NOT NULL,
  `lname` varchar(25) NOT NULL,
  `dept_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

# Dumping data for table test.employees: 0 rows
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` (`id`, `fname`, `lname`, `dept_id`) VALUES (1, 'John', 'Balmer', 1), (2, 'Steve', 'Jobs', 3), (3, 'Haisum', 'Bhatti', 2);
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
