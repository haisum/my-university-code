<?php
	require_once('preheader.php');
	require_once('ajaxCRUD.class.php');
    $tblEmployee = new ajaxCRUD("Employee", "employees", "id");
	$tblEmployee->omitPrimaryKey();
	$tblEmployee->defineRelationship("dept_id", "departments", "dept_id","dept_name");
	$tblEmployee->displayAs("fname", "First Name");
    $tblEmployee->displayAs("lname", "Last Name");
	$tblEmployee->displayAs("dept_id", "Department Name");	
	$tblEmployee->setLimit(30);
	$tblEmployee->setCSSFile('blue.css');
	$tblEmployee->showTable();	
	function makeBold($val){
		return "<b>$val</b>";
	}
	function makeBlue($val){
		return "$val";
	}
?>
