<?php
error_reporting(E_ERROR);//change this to E_NONE when in production
//also remove configurator and generate controllers  when in prodcution
define('URL','http://localhost/hadi');
define('ADMINURL','http://localhost/hadi/admincp');
define('DBNAME' , 'timetable');
define('HOST','localhost');
define('USER','root');
define('PASSWORD','');
?>