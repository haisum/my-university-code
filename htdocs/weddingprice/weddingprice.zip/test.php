 <?php
 session_start();
 //echo $_COOKIE['email'];
 //echo $_COOKIE['password'];
 print_r($_COOKIE);
 print_r($_SESSION);
 ?>