<div id="top_bar">
			
			
			<!-- Begin logo -->
			<div class="logo">
				<img src="images/logo.png" alt=""/>
			</div>
			<!-- End logo -->
			
			<!-- Begin account menu -->
			<div class="account">
				<div class="detail">
					Hello <a href=""><strong>Admin</strong></a>
				</div>
				<ul class="icon">
					<!--<li>
						<a href="" title="Message">
							<img src="images/icon_message.png" alt="" class="middle"/>
						</a>
					</li>-->
					<li>
						<a href="change_password.php" title="Change Password">
							<img src="images/icon_setting.png" alt="" class="middle"/>
						</a>
				  </li>
					<li>
						<a href="logout.php" title="Logout">
							<img src="images/icon_logout.png" alt="" class="middle"/>
						</a>
					</li>
				</ul>
			</div>
			<!-- End account menu -->
			
			
		</div>